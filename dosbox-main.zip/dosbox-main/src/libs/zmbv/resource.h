//{{NO_DEPENDENCIES}}

#define IDD_ABOUT                       101
#define IDD_CONFIGURE                   102
#define IDC_HOMEPAGE                    1000
#define IDC_EMAIL                       1001
#define IDC_SLIDER1                     1008

